import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
import { getFirestore, collection, addDoc, getDocs, doc, updateDoc, deleteDoc, query, orderBy, increment, serverTimestamp, getDoc, limit, setDoc, where } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js";
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js";

// FIREBASE CONFIG
const firebaseConfig = {
    apiKey: "AIzaSyBjiNy8apBFdLQOAiG1nCtv94DfaRwZEuM",
    authDomain: "apkverse-bjyjs.firebaseapp.com",
    databaseURL: "https://apkverse-bjyjs-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "apkverse-bjyjs",
    storageBucket: "apkverse-bjyjs.firebasestorage.app",
    messagingSenderId: "433058399647",
    appId: "1:433058399647:web:80aae884dbbd0aff94e9aa",
    measurementId: "G-6HXXD1W0KN"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// GLOBAL VARIABLES
let isEditMode = false;
let currentEditId = null;
let currentSlide = 0;
let slideInterval = null;
let banners = [];
const SLIDE_DURATION = 5000;
const ALLOWED_ADMIN_DOMAIN = ["alveemods.net", "admin.com"];
let loginAttempts = 0;
let lockUntil = 0;
const MAX_ATTEMPTS = 5;
const LOCK_DURATION_MS = 30000;

// Normalize app size into MB/GB for consistent display
function formatSize(size) {
    if (!size) return 'Unknown size';
    const str = String(size).trim();
    const num = parseFloat(str);
    const hasMB = /mb/i.test(str);
    const hasGB = /gb/i.test(str);

    if (!Number.isNaN(num)) {
        if (hasGB) return `${num.toFixed(1).replace(/\.0$/, '')} GB`;
        if (num >= 1024) return `${(num / 1024).toFixed(1).replace(/\.0$/, '')} GB`;
        return `${num.toFixed(1).replace(/\.0$/, '')} MB`;
    }

    if (hasMB) return str.replace(/mb/i, 'MB');
    if (hasGB) return str.replace(/gb/i, 'GB');
    return str;
}

// Toast Notification System
function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    
    const toast = document.createElement('div');
    const colors = {
        success: 'bg-green-600',
        error: 'bg-red-600',
        info: 'bg-blue-600',
        warning: 'bg-yellow-600'
    };
    const icons = {
        success: 'ph-check-circle',
        error: 'ph-x-circle',
        info: 'ph-info',
        warning: 'ph-warning'
    };
    
    toast.className = `${colors[type]} text-white px-6 py-4 rounded-lg shadow-2xl flex items-center gap-3 min-w-[300px] transform transition-all duration-300 opacity-0 translate-x-full`;
    toast.innerHTML = `
        <i class="ph-fill ${icons[type]} text-2xl"></i>
        <span class="flex-1 font-bold">${message}</span>
        <button onclick="this.parentElement.remove()" class="text-white/80 hover:text-white">
            <i class="ph-bold ph-x text-xl"></i>
        </button>
    `;
    
    container.appendChild(toast);
    setTimeout(() => {
        toast.classList.remove('opacity-0', 'translate-x-full');
    }, 10);
    
    setTimeout(() => {
        toast.classList.add('opacity-0', 'translate-x-full');
        setTimeout(() => toast.remove(), 300);
    }, 5000);
}

// Make showToast global
window.showToast = showToast;

// ==========================================
// 🔥 GLOBAL INITIALIZATION (Footer & Apps)
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
    loadGlobalFooter(); // Load footer on ALL pages
    
    // Track visitor
    trackVisitor();
    
    // Load apps only if on homepage
    if(document.getElementById('appGrid')) {
        loadApps();
        loadHeroSlider();
        loadHomeSections();
        loadHotApps();
        loadNewApps();
    }
    
    // Load admin if on admin page
    if(document.getElementById('loginScreen')) {
        initAdmin();
    }
});

// 🔥 DYNAMIC FOOTER SYSTEM 🔥
function loadGlobalFooter() {
    const footerContainer = document.getElementById('main-footer');
    if (!footerContainer) return;

    footerContainer.innerHTML = `
        <div class="bg-gray-900 text-white pt-12 pb-8 mt-12">
            <div class="max-w-7xl mx-auto px-4">
                <!-- Search Section in Footer -->
                <div class="mb-10">
                    <div class="max-w-2xl mx-auto">
                        <h3 class="text-center text-xl font-bold mb-4 flex items-center justify-center gap-2">
                            <i class="ph-bold ph-magnifying-glass"></i> Quick Search
                        </h3>
                        <div class="relative">
                            <input type="text" id="footerSearch" placeholder="Search for apps, games, developers..." 
                                class="w-full pl-12 pr-4 py-3 rounded-xl bg-gray-800 border border-gray-700 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition">
                            <i class="ph-bold ph-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-xl"></i>
                        </div>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 border-t border-gray-800 pt-8">
                    <div class="col-span-1">
                        <div class="flex items-center gap-2 mb-4">
                            <img src="site_logo.jpg" alt="Alvee Mods" class="w-10 h-10 rounded-lg shadow-lg border border-gray-700 object-cover bg-black p-1">
                            <span class="text-xl font-bold">Alvee <span class="text-green-500">Mods</span></span>
                        </div>
                        <p class="text-sm text-gray-400 leading-relaxed mb-4">
                            Your trusted source for safe and verified Android APK downloads. Access thousands of apps and games.
                        </p>
                        <div class="flex gap-3">
                            <a href="#" class="w-9 h-9 rounded-full bg-gray-800 hover:bg-blue-600 flex items-center justify-center transition"><i class="ph-fill ph-facebook-logo text-lg"></i></a>
                            <a href="#" class="w-9 h-9 rounded-full bg-gray-800 hover:bg-sky-500 flex items-center justify-center transition"><i class="ph-fill ph-telegram-logo text-lg"></i></a>
                            <a href="#" class="w-9 h-9 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition"><i class="ph-fill ph-x-logo text-lg"></i></a>
                            <a href="#" class="w-9 h-9 rounded-full bg-gray-800 hover:bg-red-600 flex items-center justify-center transition"><i class="ph-fill ph-youtube-logo text-lg"></i></a>
                        </div>
                    </div>

                    <div>
                        <h4 class="font-bold text-white mb-4 uppercase tracking-wider text-sm">Popular Categories</h4>
                        <ul class="space-y-2 text-sm text-gray-400">
                            <li><a href="index.html" onclick="setTimeout(() => filterCategory('Communication'), 100)" class="hover:text-green-500 transition flex items-center gap-2"><i class="ph-bold ph-chat-circle text-xs"></i> Communication</a></li>
                            <li><a href="index.html" onclick="setTimeout(() => filterCategory('Social'), 100)" class="hover:text-green-500 transition flex items-center gap-2"><i class="ph-bold ph-users text-xs"></i> Social</a></li>
                            <li><a href="index.html" onclick="setTimeout(() => filterCategory('Photography'), 100)" class="hover:text-green-500 transition flex items-center gap-2"><i class="ph-bold ph-camera text-xs"></i> Photography</a></li>
                            <li><a href="index.html" onclick="setTimeout(() => filterCategory('Tools'), 100)" class="hover:text-green-500 transition flex items-center gap-2"><i class="ph-bold ph-wrench text-xs"></i> Tools</a></li>
                            <li><a href="index.html" onclick="setTimeout(() => filterCategory('Action'), 100)" class="hover:text-green-500 transition flex items-center gap-2"><i class="ph-bold ph-game-controller text-xs"></i> Action Games</a></li>
                            <li><a href="index.html" onclick="setTimeout(() => filterCategory('Puzzle'), 100)" class="hover:text-green-500 transition flex items-center gap-2"><i class="ph-bold ph-puzzle-piece text-xs"></i> Puzzle Games</a></li>
                        </ul>
                    </div>

                    <div>
                        <h4 class="font-bold text-white mb-4 uppercase tracking-wider text-sm">Quick Links</h4>
                        <ul class="space-y-2 text-sm text-gray-400">
                            <li><a href="index.html" class="hover:text-green-500 transition flex items-center gap-2"><i class="ph-bold ph-house text-xs"></i> Home</a></li>
                            <li><a href="legal.html?page=about" class="hover:text-green-500 transition flex items-center gap-2"><i class="ph-bold ph-info text-xs"></i> About Us</a></li>
                            <li><a href="legal.html?page=contact" class="hover:text-green-500 transition flex items-center gap-2"><i class="ph-bold ph-envelope text-xs"></i> Contact Us</a></li>
                            <li><a href="legal.html?page=privacy" class="hover:text-green-500 transition flex items-center gap-2"><i class="ph-bold ph-shield-check text-xs"></i> Privacy Policy</a></li>
                            <li><a href="legal.html?page=terms" class="hover:text-green-500 transition flex items-center gap-2"><i class="ph-bold ph-scroll text-xs"></i> Terms of Service</a></li>
                            <li><a href="legal.html?page=dmca" class="hover:text-red-400 transition flex items-center gap-2"><i class="ph-bold ph-copyright text-xs"></i> DMCA</a></li>
                        </ul>
                    </div>

                    <div>
                        <h4 class="font-bold text-white mb-4 uppercase tracking-wider text-sm">Trust & Safety</h4>
                        <div class="space-y-3">
                            <div class="bg-gray-800 border border-gray-700 p-3 rounded-lg">
                                <div class="flex items-center gap-2 text-green-500 font-bold text-xs mb-1">
                                    <i class="ph-fill ph-shield-check text-lg"></i> Verified Safe
                                </div>
                                <p class="text-[10px] text-gray-400 leading-tight">
                                    All APKs scanned for malware
                                </p>
                            </div>
                            <div class="bg-gray-800 border border-gray-700 p-3 rounded-lg">
                                <div class="flex items-center gap-2 text-blue-500 font-bold text-xs mb-1">
                                    <i class="ph-fill ph-lightning text-lg"></i> Fast Downloads
                                </div>
                                <p class="text-[10px] text-gray-400 leading-tight">
                                    Optimized CDN servers
                                </p>
                            </div>
                            <div class="bg-gray-800 border border-gray-700 p-3 rounded-lg">
                                <div class="flex items-center gap-2 text-purple-500 font-bold text-xs mb-1">
                                    <i class="ph-fill ph-globe text-lg"></i> No Geo-Blocks
                                </div>
                                <p class="text-[10px] text-gray-400 leading-tight">
                                    Access any region apps
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="border-t border-gray-800 pt-6 flex flex-col md:flex-row justify-between items-center gap-4">
                    <p class="text-xs text-gray-500">&copy; 2025 Alvee Mods. All rights reserved.</p>
                    <div class="flex items-center gap-4 text-xs text-gray-500">
                        <span>Made with <i class="ph-fill ph-heart text-red-500"></i> for Android users</span>
                        <span class="hidden md:inline">|</span>
                        <span class="text-gray-400">Android™ is a trademark of Google LLC</span>
                    </div>
                </div>
            </div>
        </div>
        <script>
            // Footer search functionality
            const footerSearch = document.getElementById('footerSearch');
            if(footerSearch) {
                footerSearch.addEventListener('input', (e) => {
                    const searchValue = e.target.value;
                    // Sync with header searches
                    const headerSearch = document.getElementById('searchInput');
                    const mobileSearch = document.getElementById('searchInputMobile');
                    if(headerSearch) headerSearch.value = searchValue;
                    if(mobileSearch) mobileSearch.value = searchValue;
                    
                    // Trigger search if on homepage
                    if(window.location.pathname.includes('index.html') || window.location.pathname === '/') {
                        const event = new Event('input', { bubbles: true });
                        if(headerSearch) headerSearch.dispatchEvent(event);
                    }
                });
            }
        </script>
    `;
}

// ==========================================
// 1. HOME PAGE LOGIC (OPTIMIZED)
// ==========================================

let appsCache = null;
let lastFetchTime = 0;
const CACHE_DURATION = 60000; // 1 minute cache

export async function loadApps(category = 'All', searchQuery = '', sortBy = 'uploadedAt') {
    const grid = document.getElementById('appGrid');
    const loading = document.getElementById('loading');
    if(!grid) return;

    grid.innerHTML = '';
    loading.classList.remove('hidden');

    try {
        // Use cache if available and fresh
        const now = Date.now();
        if(appsCache && (now - lastFetchTime) < CACHE_DURATION && category === 'All' && !searchQuery && sortBy === 'uploadedAt') {
            renderFromCache(appsCache, grid);
            loading.classList.add('hidden');
            return;
        }
        
        const q = query(collection(db, "apps"), orderBy(sortBy, "desc"));
        const snapshot = await getDocs(q);
        
        // Update cache
        if(category === 'All' && !searchQuery && sortBy === 'uploadedAt') {
            appsCache = snapshot;
            lastFetchTime = now;
        }
        
        loading.classList.add('hidden');
        
        let hasResults = false;
        snapshot.forEach((doc) => {
            const data = doc.data();
            const matchesCategory = category === 'All' || data.category === category;
            const matchesSearch = searchQuery === '' || 
                data.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                data.developer?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                data.packageName?.toLowerCase().includes(searchQuery.toLowerCase());
            
            if (matchesCategory && matchesSearch) {
                hasResults = true;
                renderAppCard(doc.id, data, grid);
            }
        });

        if (!hasResults) {
            grid.innerHTML = `
                <div class="col-span-full py-16">
                    <div class="text-center">
                        <div class="inline-block p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-full mb-4">
                            <i class="ph-bold ph-magnifying-glass text-4xl text-blue-600"></i>
                        </div>
                        <h3 class="text-xl font-bold text-gray-700 mb-2">No apps found</h3>
                        <p class="text-gray-500 mb-4">Try adjusting your search or filter criteria</p>
                        <button onclick="window.location.href='index.html'" class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition text-sm">
                            <i class="ph-bold ph-house"></i> Back to Home
                        </button>
                    </div>
                </div>
            `;
        }
    } catch (e) { console.error(e); loading.classList.add('hidden'); }
}

function renderFromCache(snapshot, grid) {
    snapshot.forEach((doc) => {
        renderAppCard(doc.id, doc.data(), grid);
    });
}

// ==========================================
// 🔥 HERO SLIDER SYSTEM
// ==========================================

export async function loadHeroSlider() {
    const track = document.getElementById('sliderTrack');
    const dotsContainer = document.getElementById('sliderDots');
    if(!track || !dotsContainer) return;

    try {
        const q = query(collection(db, "banners"), orderBy("order", "asc"));
        const snapshot = await getDocs(q);
        
        track.innerHTML = '';
        dotsContainer.innerHTML = '';
        banners = [];
        
        if(snapshot.empty) {
            track.innerHTML = `<div class="w-full h-full flex items-center justify-center bg-gradient-to-r from-green-600 to-blue-600 text-white">
                <div class="text-center"><h2 class="text-4xl font-bold mb-2">Welcome to Alvee Mods</h2><p class="text-lg opacity-90">Your trusted Android APK destination</p></div>
            </div>`;
            return;
        }

        const hero = document.getElementById('heroSlider');
        if(hero) {
            hero.addEventListener('mouseenter', pauseAutoSlide);
            hero.addEventListener('mouseleave', resetAutoSlide);
            hero.addEventListener('touchstart', pauseAutoSlide, { passive: true });
            hero.addEventListener('touchend', resetAutoSlide, { passive: true });
        }
        
        snapshot.forEach((doc, index) => {
            const banner = doc.data();
            banners.push({ id: doc.id, ...banner });
            
            track.innerHTML += `<div class="slide-item min-w-full h-full relative" onclick="navigateSlide('${banner.link}')">
                <img src="${banner.imageUrl}" alt="${banner.title}" class="w-full h-full object-cover" onerror="this.style.display='none'">
                <div class="absolute inset-0 bg-gradient-to-b from-black/60 via-black/20 to-black/60"></div>
                <div class="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(255,255,255,0.08),transparent_45%),radial-gradient(circle_at_80%_30%,rgba(255,255,255,0.05),transparent_40%)]"></div>
                <div class="absolute bottom-8 left-8 right-8 text-white max-w-2xl drop-shadow">
                    <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur text-xs font-bold uppercase tracking-wide mb-3">Featured</div>
                    <h2 class="text-2xl md:text-4xl font-bold mb-2 leading-tight">${banner.title}</h2>
                    <p class="text-sm md:text-base opacity-90 leading-relaxed">${banner.description || ''}</p>
                </div>
            </div>`;
            
            dotsContainer.innerHTML += `<button onclick="goToSlide(${index})" class="hero-dot ${index === 0 ? 'active' : ''}" data-dot="${index}"></button>`;
        });
        
        startAutoSlide();
    } catch (e) { console.error('Slider error:', e); }
}

window.navigateSlide = (link) => { if(link && link !== '#') window.location.href = link; };

window.nextSlide = () => {
    if(banners.length === 0) return;
    currentSlide = (currentSlide + 1) % banners.length;
    updateSlider();
};

window.prevSlide = () => {
    if(banners.length === 0) return;
    currentSlide = (currentSlide - 1 + banners.length) % banners.length;
    updateSlider();
};

window.goToSlide = (index) => {
    currentSlide = index;
    updateSlider();
};

function updateSlider() {
    const track = document.getElementById('sliderTrack');
    if(!track) return;
    
    track.style.transform = `translateX(-${currentSlide * 100}%)`;
    
    document.querySelectorAll('[data-dot]').forEach((dot, idx) => {
        if(idx === currentSlide) {
            dot.className = 'hero-dot active';
        } else {
            dot.className = 'hero-dot';
        }
    });
    
    resetAutoSlide();
}

function startAutoSlide() {
    if(banners.length <= 1) return;
    slideInterval = setInterval(() => {
        window.nextSlide();
    }, SLIDE_DURATION);
}

function resetAutoSlide() {
    if(slideInterval) clearInterval(slideInterval);
    startAutoSlide();
}

function pauseAutoSlide() {
    if(slideInterval) clearInterval(slideInterval);
    slideInterval = null;
}

// ==========================================
// Hot & New Sections
// ==========================================

async function loadHotApps() {
    const grid = document.getElementById('hotGrid');
    if(!grid) return;
    try {
        const q = query(collection(db, "apps"), orderBy("downloads", "desc"), limit(10));
        const snapshot = await getDocs(q);
        grid.innerHTML = '';
        snapshot.forEach((doc) => {
            renderMiniCard(doc.id, doc.data(), grid);
        });
    } catch (e) { console.error(e); }
}

async function loadNewApps() {
    const grid = document.getElementById('newGrid');
    if(!grid) return;
    try {
        const q = query(collection(db, "apps"), orderBy("uploadedAt", "desc"), limit(10));
        const snapshot = await getDocs(q);
        grid.innerHTML = '';
        snapshot.forEach((doc) => {
            renderMiniCard(doc.id, doc.data(), grid);
        });
    } catch (e) { console.error(e); }
}

function renderMiniCard(id, app, container) {
    const displaySize = formatSize(app.size);
    const fallbackImage = `https://ui-avatars.com/api/?name=${encodeURIComponent(app.name)}&background=random&size=128`;
    container.innerHTML += `<div onclick="window.location.href='app-details.html?id=${id}'" class="group bg-white/95 backdrop-blur-sm border border-white/20 rounded-2xl p-4 shadow-xl hover:shadow-2xl transition hover:-translate-y-2 hover:scale-105 cursor-pointer">
        <img src="${app.iconUrl}" onerror="this.src='${fallbackImage}'" class="w-16 h-16 mx-auto rounded-xl object-cover border-2 border-white/50 bg-white shadow-lg group-hover:scale-110 transition mb-3">
        <h4 class="font-bold text-gray-900 text-sm text-center truncate group-hover:text-green-600 transition">${app.name}</h4>
        <div class="text-xs text-gray-600 text-center mt-1 font-medium">${displaySize}</div>
        <div class="mt-2 pt-2 border-t border-gray-100 flex items-center justify-center gap-1">
            <i class="ph-fill ph-download text-green-600 text-xs"></i>
            <span class="text-[10px] text-gray-500 font-bold">${app.downloads || 0}</span>
        </div>
    </div>`;
}

// ==========================================
// Homepage Featured Sections
// ==========================================

export async function loadHomeSections() {
    const container = document.getElementById('categorySections');
    if(!container) return;
    container.innerHTML = '';

    try {
        const sectionsSnap = await getDocs(query(collection(db, "sections"), orderBy("order", "asc")));
        if(sectionsSnap.empty) { container.classList.add('hidden'); return; }
        container.classList.remove('hidden');

        for (const secDoc of sectionsSnap.docs) {
            const sec = secDoc.data();
            const appsSnap = await getDocs(query(collection(db, "apps"), where("category", "==", sec.category), orderBy("downloads", "desc"), limit(6)));

            let appsHtml = '';
            appsSnap.forEach((docItem) => {
                const app = docItem.data();
                const displaySize = formatSize(app.size);
                const fallbackImage = `https://ui-avatars.com/api/?name=${encodeURIComponent(app.name)}&background=random&size=128`;
                appsHtml += `<div onclick="window.location.href='app-details.html?id=${docItem.id}'" class="group bg-white border border-gray-100 rounded-xl p-3 shadow-sm hover:shadow-lg transition hover:-translate-y-1">
                    <div class="flex items-center gap-3">
                        <img src="${app.iconUrl}" onerror="this.src='${fallbackImage}'" class="w-12 h-12 rounded-lg object-cover border border-gray-100 bg-gray-50 group-hover:scale-105 transition">
                        <div class="min-w-0 flex-1">
                            <div class="font-bold text-gray-900 text-sm truncate group-hover:text-green-600">${app.name}</div>
                            <div class="text-[11px] text-gray-500 truncate">${app.developer || 'Unknown'}</div>
                            <div class="flex items-center gap-2 mt-1 text-[10px] text-gray-500">
                                <span class="bg-gray-100 px-1.5 rounded">v${app.version}</span>
                                <span class="bg-blue-50 text-blue-600 px-1.5 rounded">${displaySize}</span>
                                <span class="bg-purple-50 text-purple-600 px-1.5 rounded">🔥 ${app.downloads || 0}</span>
                            </div>
                        </div>
                    </div>
                </div>`;
            });

            if(appsHtml === '') appsHtml = '<div class="text-gray-400 text-sm">No apps in this category yet.</div>';

            container.innerHTML += `<section class="bg-white rounded-2xl p-5 md:p-6 border border-gray-100 shadow-sm animate-fade-in-up">
                <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-2 mb-4">
                    <div>
                        <h3 class="text-lg font-bold text-gray-900 flex items-center gap-2"><i class="ph-bold ph-folders text-green-600"></i> ${sec.title || sec.category}</h3>
                        <p class="text-sm text-gray-500">${sec.description || 'Curated picks from this category.'}</p>
                    </div>
                    <button class="text-xs font-bold text-green-600 underline" onclick="filterCategory('${sec.category}')">View all ${sec.category}</button>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
                    ${appsHtml}
                </div>
            </section>`;
        }
    } catch (e) {
        console.error('Sections load error', e);
        container.classList.add('hidden');
    }
}

function renderAppCard(id, app, container) {
    const displaySize = formatSize(app.size);
    const fallbackImage = `https://ui-avatars.com/api/?name=${encodeURIComponent(app.name)}&background=random&size=128`;
    const card = document.createElement('div');
    card.className = 'group bg-white rounded-xl md:rounded-2xl p-3 md:p-5 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 border border-gray-100 cursor-pointer h-full flex flex-col items-center text-center relative overflow-hidden animate-fade-in-up';
    card.onclick = () => window.location.href = `app-details.html?id=${id}`;
    card.innerHTML = `
        <div class="absolute inset-0 bg-gradient-to-b from-transparent to-green-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        <div class="relative z-10 mb-2 md:mb-3">
            <img src="${app.iconUrl}" onerror="this.src='${fallbackImage}'" alt="${app.name}" class="w-14 h-14 md:w-20 md:h-20 rounded-xl md:rounded-2xl shadow-sm object-cover bg-gray-50 border border-gray-100 group-hover:scale-105 transition-transform duration-300">
        </div>
        <div class="w-full relative z-10 flex flex-col items-center flex-1">
            <h3 class="font-bold text-gray-800 text-xs md:text-base leading-tight line-clamp-2 h-8 md:h-10 flex items-center justify-center group-hover:text-green-600 transition-colors">${app.name}</h3>
            <p class="hidden md:block text-[10px] text-gray-400 mt-1 truncate w-full">${app.developer || 'Unknown'}</p>
            <div class="flex items-center gap-1 md:gap-2 mt-2 text-[9px] md:text-[10px] text-gray-500 font-medium">
                <span class="bg-gray-50 px-1.5 py-0.5 rounded border border-gray-100">v${app.version}</span>
                <span class="bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded border border-blue-100">${displaySize}</span>
            </div>
        </div>
        <div class="mt-3 w-full relative z-10">
            <button class="w-full flex items-center justify-center gap-2 text-[10px] md:text-xs font-bold text-white bg-green-600 py-2 md:py-2.5 rounded-lg md:rounded-xl shadow-sm group-hover:bg-green-700 transition-colors">Download</button>
        </div>`;
    container.appendChild(card);
}

// ==========================================
// 2. DETAILS PAGE LOGIC
// ==========================================

export async function loadAppDetails(id) {
    const container = document.getElementById('detailsContainer');
    if(!container) return; 
    try {
        const docSnap = await getDoc(doc(db, "apps", id));
        if (docSnap.exists()) {
            const app = docSnap.data();
            renderFullDetails(id, app, container);
            loadRecommendedApps(id);
        } else {
            container.innerHTML = '<div class="text-center py-20 text-red-500 text-sm">App not found!</div>';
        }
    } catch (e) { container.innerHTML = '<div class="text-center py-20 text-red-500 text-sm">Error loading app.</div>'; }
}

function renderFullDetails(id, app, container) {
    const displaySize = formatSize(app.size);
    let screenshotsHtml = '';
    if(app.screenshots && app.screenshots.trim() !== '') {
        const shots = app.screenshots.split(',').filter(url => url.trim().length > 0);
        if(shots.length > 0) {
            screenshotsHtml = `<div class="mb-6 md:mb-8"><h3 class="font-bold text-gray-900 text-lg md:text-xl mb-3 md:mb-4 flex items-center gap-2"><i class="ph-bold ph-images text-green-600"></i> Screenshots</h3><div class="flex gap-3 overflow-x-auto pb-4 no-scrollbar snap-x snap-mandatory">` + 
                shots.map(url => `<img src="${url.trim()}" onerror="this.style.display='none'" class="screenshot-zoom h-48 md:h-64 rounded-lg md:rounded-xl shadow-md border bg-gray-50 object-cover snap-center shrink-0 cursor-pointer" onclick="window.open('${url.trim()}', '_blank')">`).join('') + `</div></div>`;
        }
    }
    const techHtml = generateTechHtml(app.techData);
    const fallbackImage = `https://ui-avatars.com/api/?name=${encodeURIComponent(app.name)}&background=random&size=128`;

    container.innerHTML = `
        <div class="flex flex-col md:flex-row gap-6 md:gap-8 mb-6 md:mb-8 items-center md:items-start border-b border-gray-100 pb-6 md:pb-8">
            <img src="${app.iconUrl}" onerror="this.src='${fallbackImage}'" class="w-24 h-24 md:w-32 md:h-32 rounded-2xl md:rounded-[2rem] shadow-lg bg-white object-cover border border-gray-100">
            <div class="text-center md:text-left flex-1">
                <h1 class="text-2xl md:text-4xl font-extrabold text-gray-900 mb-1 md:mb-2">${app.name}</h1>
                <p class="text-xs md:text-base text-green-600 font-bold mb-2 flex items-center justify-center md:justify-start gap-1">${app.developer} <i class="ph-fill ph-check-circle"></i></p>
                <p class="text-[10px] md:text-sm text-gray-400 font-mono mb-4 md:mb-6">${app.packageName}</p>
                <div class="flex flex-wrap justify-center md:justify-start gap-2 md:gap-3 mb-4">
                    <span class="bg-gray-100 px-3 py-1 rounded-lg font-bold text-gray-600 text-xs md:text-sm flex items-center gap-1"><i class="ph-bold ph-tag"></i> v${app.version}</span>
                    <span class="bg-blue-50 text-blue-600 px-3 py-1 rounded-lg font-bold text-xs md:text-sm flex items-center gap-1"><i class="ph-bold ph-folder"></i> ${app.category}</span>
                    <span class="bg-orange-50 text-orange-600 px-3 py-1 rounded-lg font-bold text-xs md:text-sm flex items-center gap-1"><i class="ph-bold ph-hard-drives"></i> ${displaySize}</span>
                    <span class="bg-purple-50 text-purple-600 px-3 py-1 rounded-lg font-bold text-xs md:text-sm flex items-center gap-1"><i class="ph-bold ph-download-simple"></i> ${app.downloads || 0} downloads</span>
                </div>
            </div>
        </div>
        
        <!-- Download Section -->
        <div class="bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl p-6 mb-8 border border-green-200">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <h3 class="text-lg font-bold text-gray-900 mb-1">Download APK</h3>
                    <p class="text-sm text-gray-600">Verified safe • Scanned for malware</p>
                </div>
                <div class="flex items-center gap-2 text-green-600">
                    <i class="ph-fill ph-shield-check text-3xl"></i>
                </div>
            </div>
            <a href="${app.apkUrl}" target="_blank" onclick="trackDownload('${id}')" class="flex items-center justify-center gap-2 md:gap-3 w-full bg-green-600 hover:bg-green-700 text-white font-bold text-sm md:text-lg py-4 md:py-5 rounded-xl md:rounded-2xl shadow-xl shadow-green-200 transition transform hover:-translate-y-1">
                <i class="ph-bold ph-download-simple text-lg md:text-2xl"></i> Download ${displaySize}
            </a>
        </div>
        
        ${screenshotsHtml}
        
        <div class="bg-gray-50 rounded-xl md:rounded-2xl p-5 md:p-6 border border-gray-100 mb-6 md:mb-8">
            <h3 class="font-bold text-gray-900 mb-2 md:mb-3 text-sm md:text-lg flex items-center gap-2"><i class="ph-bold ph-info text-blue-600"></i> About this app</h3>
            <p class="text-gray-600 leading-relaxed whitespace-pre-line text-xs md:text-base">${app.description || 'No description provided.'}</p>
        </div>
        
        <div class="bg-white rounded-xl md:rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            <div class="bg-gray-50 px-5 md:px-6 py-3 md:py-4 border-b border-gray-200">
                <h3 class="font-bold text-gray-900 flex items-center gap-2 text-xs md:text-base"><i class="ph-fill ph-code text-blue-600"></i> Technical Information</h3>
            </div>
            <div class="p-5 md:p-6">${techHtml}</div>
        </div>`;
}

function generateTechHtml(d) {
    if(!d) return '<div class="text-gray-400 italic text-xs">No details.</div>';
    const row = (k, v) => `<div class="flex justify-between py-1.5 md:py-2 border-b border-gray-50 text-xs md:text-sm"><span class="font-bold text-gray-700">${k}</span><span class="font-mono text-gray-600 text-right">${v || '-'}</span></div>`;
    return `<div class="space-y-4 md:space-y-6"><div><div class="font-bold text-blue-800 text-[10px] md:text-xs uppercase mb-1 md:mb-2">Build</div>${row('Version Code', d.verCode)}${row('Min SDK', d.minSdk)}${row('Target SDK', d.targetSdk)}</div><div><div class="font-bold text-blue-800 text-[10px] md:text-xs uppercase mb-1 md:mb-2">Signature</div><div class="text-[9px] md:text-[10px] text-gray-500 break-all font-mono bg-gray-50 p-1.5 md:p-2 border rounded mb-1">SHA-1: ${d.sha1 || '-'}</div><div class="text-[9px] md:text-[10px] text-gray-500 break-all font-mono bg-gray-50 p-1.5 md:p-2 border rounded">SHA-256: ${d.sha256 || '-'}</div></div></div>`;
}

async function loadRecommendedApps(currentId) {
    const grid = document.getElementById('recommendedGrid');
    if(!grid) return;
    try {
        const q = query(collection(db, "apps"), orderBy("downloads", "desc"), limit(6));
        const snapshot = await getDocs(q);
        grid.innerHTML = '';
        let count = 0;
        snapshot.forEach((doc) => {
            if(doc.id !== currentId && count < 5) {
                const app = doc.data();
                const displaySize = formatSize(app.size);
                grid.innerHTML += `<div onclick="window.location.href='app-details.html?id=${doc.id}'" class="flex items-center gap-3 p-2 md:p-3 hover:bg-gray-50 rounded-lg cursor-pointer transition border border-transparent hover:border-gray-100 group"><img src="${app.iconUrl}" class="w-10 h-10 md:w-12 md:h-12 rounded-lg bg-gray-100 object-cover shadow-sm"><div class="min-w-0 flex-1"><h4 class="font-bold text-gray-900 text-xs md:text-sm truncate group-hover:text-green-600 transition">${app.name}</h4><div class="flex items-center gap-2 text-[10px] md:text-xs text-gray-500 mt-0.5"><span class="bg-gray-100 px-1.5 rounded">${displaySize}</span><span>🔥 ${app.downloads || 0}</span></div></div></div>`;
                count++;
            }
        });
        if(count === 0) grid.innerHTML = '<div class="text-gray-400 text-xs text-center">No recommendations.</div>';
    } catch (e) { console.error(e); }
}
window.trackDownload = (id) => updateDoc(doc(db, "apps", id), { downloads: increment(1) });

// ==========================================
// 3. ADMIN LOGIC
// ==========================================

export function initAdmin() {
    onAuthStateChanged(auth, (user) => {
        if (user) {
            document.getElementById('loginScreen').classList.add('hidden');
            document.getElementById('dashboard').classList.remove('hidden');
            loadAdminList();
            if(document.getElementById('bannerList')) loadBannerList();
            if(document.getElementById('sectionList')) loadSectionList();
        } else {
            document.getElementById('loginScreen').classList.remove('hidden');
            document.getElementById('dashboard').classList.add('hidden');
        }
    });

    const loginForm = document.getElementById('loginForm');
    if(loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const now = Date.now();
            if (now < lockUntil) {
                const wait = Math.ceil((lockUntil - now) / 1000);
                showToast(`Too many attempts. Try again in ${wait}s.`, 'error');
                return;
            }

            const emailVal = document.getElementById('email').value.trim();
            if (!emailVal.toLowerCase().endsWith(`@${ALLOWED_ADMIN_DOMAIN}`)) {
    showToast(`Admin access limited to @${ALLOWED_ADMIN_DOMAIN} emails.`, 'error');
    return;
}


            signInWithEmailAndPassword(auth, emailVal, document.getElementById('password').value)
                .then(() => { loginAttempts = 0; })
                .catch(err => {
                    loginAttempts += 1;
                    if (loginAttempts >= MAX_ATTEMPTS) {
                        lockUntil = Date.now() + LOCK_DURATION_MS;
                        showToast(`Too many failed attempts. Locked for ${LOCK_DURATION_MS/1000}s.`, 'error');
                    } else {
                        showToast("Login Failed: " + err.code, 'error');
                    }
                });
        });
    }
    const uploadForm = document.getElementById('uploadForm');
    if(uploadForm) uploadForm.addEventListener('submit', handleFormSubmit);
}

async function loadAdminList() {
    const list = document.getElementById('adminAppList');
    if(!list) return;
    list.innerHTML = '<li class="p-6 text-center text-gray-400 text-sm animate-pulse">Loading apps...</li>';
    try {
        const q = query(collection(db, "apps"), orderBy("uploadedAt", "desc"));
        const snapshot = await getDocs(q);
        list.innerHTML = '';
        if (snapshot.empty) { list.innerHTML = '<li class="p-6 text-center text-gray-400 text-sm">No apps found.</li>'; return; }
        snapshot.forEach(doc => {
            const app = doc.data();
            list.innerHTML += `<li class="p-4 bg-white hover:bg-gray-50 flex flex-col md:flex-row justify-between md:items-center gap-3 transition border-b border-gray-100 last:border-0"><div class="flex items-center gap-4 min-w-0 flex-1"><img src="${app.iconUrl}" onerror="this.src='https://via.placeholder.com/40'" class="w-10 h-10 rounded-lg shadow-sm object-cover border border-gray-200 bg-gray-50 flex-shrink-0"><div class="min-w-0 flex-1"><div class="font-bold text-gray-800 text-sm truncate">${app.name}</div><div class="text-xs text-gray-500 font-mono truncate">${app.packageName}</div></div></div><div class="flex gap-2 flex-shrink-0"><button onclick="editApp('${doc.id}')" class="px-3 py-1.5 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-lg text-xs font-bold transition">Edit</button><button onclick="deleteApp('${doc.id}')" class="px-3 py-1.5 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg text-xs font-bold transition">Delete</button></div></li>`;
        });
    } catch (error) { list.innerHTML = `<li class="p-6 text-center text-red-500 text-sm">Error: ${error.message}</li>`; }
}

async function handleFormSubmit(e) {
    e.preventDefault();
    document.getElementById('uploadingScreen').classList.remove('hidden');
    
    const techData = {
        verCode: document.getElementById('t_verCode').value,
        date: document.getElementById('t_date').value,
        compress: document.getElementById('t_compress').value,
        minSdk: document.getElementById('t_minSdk').value,
        targetSdk: document.getElementById('t_targetSdk').value,
        compileSdk: document.getElementById('t_compileSdk').value,
        abi: document.getElementById('t_abi').value,
        devices: document.getElementById('t_devices').value,
        v1: document.getElementById('t_v1').checked,
        v2: document.getElementById('t_v2').checked,
        v3: document.getElementById('t_v3').checked,
        v4: document.getElementById('t_v4').checked,
        algo: document.getElementById('t_algo').value,
        sha1: document.getElementById('t_sha1').value,
        sha256: document.getElementById('t_sha256').value,
        issuer: document.getElementById('t_issuer').value,
        proguard: document.getElementById('t_proguard').value,
        obfus: document.getElementById('t_obfus').value,
        debug: document.getElementById('t_debug').value,
        perms: document.getElementById('t_perms').value
    };

    const appData = {
        name: document.getElementById('appName').value,
        packageName: document.getElementById('packageName').value,
        developer: document.getElementById('developer').value,
        category: document.getElementById('category').value,
        size: document.getElementById('size').value,
        version: document.getElementById('version').value,
        apkUrl: document.getElementById('apkUrl').value,
        iconUrl: document.getElementById('iconUrl').value,
        screenshots: document.getElementById('screenshots').value,
        techData: techData,
        updatedAt: serverTimestamp()
    };

    try {
        if (isEditMode && currentEditId) { await updateDoc(doc(db, "apps", currentEditId), appData); }
        else { appData.downloads = 0; appData.uploadedAt = serverTimestamp(); await addDoc(collection(db, "apps"), appData); }
        setTimeout(() => { document.getElementById('successScreen').classList.remove('hidden'); document.getElementById('uploadingScreen').classList.add('hidden'); loadAdminList(); }, 500);
    } catch (error) { showToast("Error: " + error.message, 'error'); document.getElementById('uploadingScreen').classList.add('hidden'); }
}

// ==========================================
// 4. BANNER MANAGEMENT
// ==========================================

async function loadBannerList() {
    const list = document.getElementById('bannerList');
    if(!list) return;
    list.innerHTML = '<div class="p-4 text-center text-gray-400 text-sm">Loading...</div>';
    try {
        const q = query(collection(db, "banners"), orderBy("order", "asc"));
        const snapshot = await getDocs(q);
        list.innerHTML = '';
        if(snapshot.empty) { list.innerHTML = '<div class="p-6 text-center text-gray-400 text-sm">No banners yet. Add one!</div>'; return; }
        snapshot.forEach(doc => {
            const banner = doc.data();
            list.innerHTML += `<div class="flex flex-col md:flex-row items-start md:items-center gap-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
                <img src="${banner.imageUrl}" class="w-full md:w-32 h-20 object-cover rounded-lg shadow-sm">
                <div class="flex-1 min-w-0">
                    <div class="font-bold text-sm text-gray-800 truncate">${banner.title}</div>
                    <div class="text-xs text-gray-500 mt-1 truncate">Order: ${banner.order} | Link: ${banner.link}</div>
                </div>
                <div class="flex gap-2 flex-shrink-0 w-full md:w-auto">
                    <button onclick="editBanner('${doc.id}')" class="flex-1 md:flex-none px-3 py-1.5 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-lg text-xs font-bold transition">Edit</button>
                    <button onclick="deleteBanner('${doc.id}')" class="flex-1 md:flex-none px-3 py-1.5 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg text-xs font-bold transition">Delete</button>
                </div>
            </div>`;
        });
    } catch(e) { list.innerHTML = `<div class="p-6 text-center text-red-500 text-sm">Error: ${e.message}</div>`; }
}

window.saveBanner = async () => {
    const bannerData = {
        title: document.getElementById('bannerTitle').value,
        description: document.getElementById('bannerDesc').value,
        imageUrl: document.getElementById('bannerImage').value,
        link: document.getElementById('bannerLink').value,
        order: parseInt(document.getElementById('bannerOrder').value) || 0,
        updatedAt: serverTimestamp()
    };
    
    try {
        const editId = document.getElementById('bannerForm').dataset.editId;
        if(editId) { await updateDoc(doc(db, "banners", editId), bannerData); }
        else { bannerData.createdAt = serverTimestamp(); await addDoc(collection(db, "banners"), bannerData); }
        
        document.getElementById('bannerForm').reset();
        document.getElementById('bannerForm').dataset.editId = '';
        loadBannerList();
        showToast('Banner saved!', 'success');
    } catch(e) { showToast('Error: ' + e.message, 'error'); }
};

window.editBanner = async (id) => {
    try {
        const docSnap = await getDoc(doc(db, "banners", id));
        if(docSnap.exists()) {
            const data = docSnap.data();
            document.getElementById('bannerTitle').value = data.title || '';
            document.getElementById('bannerDesc').value = data.description || '';
            document.getElementById('bannerImage').value = data.imageUrl || '';
            document.getElementById('bannerLink').value = data.link || '';
            document.getElementById('bannerOrder').value = data.order || 0;
            document.getElementById('bannerForm').dataset.editId = id;
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    } catch(e) { showToast(e.message, 'error'); }
};

window.deleteBanner = async (id) => {
    if(confirm('Delete this banner?')) {
        try { await deleteDoc(doc(db, "banners", id)); showToast('Banner deleted', 'success'); loadBannerList(); }
        catch(e) { showToast(e.message, 'error'); }
    }
};

// ==========================================
// 4b. HOME SECTIONS MANAGEMENT
// ==========================================

window.loadSectionList = async () => {
    const list = document.getElementById('sectionList');
    if(!list) return;
    list.innerHTML = '<div class="text-center text-gray-400 text-sm">Loading sections...</div>';
    try {
        const snapshot = await getDocs(query(collection(db, "sections"), orderBy("order", "asc")));
        if(snapshot.empty) { list.innerHTML = '<div class="text-center text-gray-400 text-sm">No sections yet.</div>'; return; }
        list.innerHTML = '';
        snapshot.forEach(secDoc => {
            const data = secDoc.data();
            list.innerHTML += `<div class="p-3 border border-gray-100 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-2 hover:bg-gray-50 transition">
                <div class="flex-1 min-w-0">
                    <div class="font-bold text-gray-900 text-sm truncate">${data.title || data.category}</div>
                    <div class="text-[11px] text-gray-500 truncate">${data.category} • Order ${data.order ?? 0}</div>
                </div>
                <div class="flex gap-2 flex-shrink-0 w-full md:w-auto">
                    <button onclick="editSection('${secDoc.id}')" class="flex-1 md:flex-none px-3 py-1.5 bg-blue-50 text-blue-600 rounded-lg text-xs font-bold hover:bg-blue-100">Edit</button>
                    <button onclick="deleteSection('${secDoc.id}')" class="flex-1 md:flex-none px-3 py-1.5 bg-red-50 text-red-600 rounded-lg text-xs font-bold hover:bg-red-100">Delete</button>
                </div>
            </div>`;
        });
    } catch (e) {
        list.innerHTML = `<div class="text-center text-red-500 text-sm">Error: ${e.message}</div>`;
    }
};

window.saveSection = async () => {
    const title = document.getElementById('sectionTitle').value.trim();
    const category = document.getElementById('sectionCategory').value;
    const description = document.getElementById('sectionDesc').value.trim();
    const orderVal = parseInt(document.getElementById('sectionOrder').value, 10) || 0;
    const form = document.getElementById('sectionForm');
    const editId = form?.dataset.editId;

    const data = {
        title,
        category,
        description,
        order: orderVal,
        updatedAt: serverTimestamp()
    };

    try {
        if(editId) {
            await updateDoc(doc(db, "sections", editId), data);
        } else {
            await addDoc(collection(db, "sections"), { ...data, createdAt: serverTimestamp() });
        }
        showToast('Section saved', 'success');
        resetSectionForm();
        loadSectionList();
        loadHomeSections();
    } catch (e) {
        showToast('Error: ' + e.message, 'error');
    }
};

window.editSection = async (id) => {
    try {
        const docSnap = await getDoc(doc(db, "sections", id));
        if(docSnap.exists()) {
            const data = docSnap.data();
            document.getElementById('sectionTitle').value = data.title || '';
            document.getElementById('sectionCategory').value = data.category || '';
            document.getElementById('sectionDesc').value = data.description || '';
            document.getElementById('sectionOrder').value = data.order ?? 0;
            document.getElementById('sectionForm').dataset.editId = id;
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    } catch (e) { showToast(e.message, 'error'); }
};

window.deleteSection = async (id) => {
    if(confirm('Delete this section?')) {
        try { await deleteDoc(doc(db, "sections", id)); showToast('Section deleted', 'success'); loadSectionList(); loadHomeSections(); }
        catch (e) { showToast(e.message, 'error'); }
    }
};

window.resetSectionForm = () => {
    document.getElementById('sectionForm').reset();
    document.getElementById('sectionForm').dataset.editId = '';
    document.getElementById('sectionOrder').value = 0;
};

// ==========================================
// 6. VISITOR TRACKING & INSIGHTS
// ==========================================

async function trackVisitor() {
    try {
        const visitorId = getOrCreateVisitorId();
        const deviceType = getDeviceType();
        const country = getCountry();
        
        const visitData = {
            visitorId,
            deviceType,
            country: country || 'Unknown',
            page: window.location.pathname,
            timestamp: serverTimestamp(),
            userAgent: navigator.userAgent
        };
        
        await addDoc(collection(db, "visits"), visitData);
    } catch (e) { console.error('Tracking error:', e); }
}

function getOrCreateVisitorId() {
    let id = localStorage.getItem('alveemods_visitor_id');
    if (!id) {
        id = 'v_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        localStorage.setItem('alveemods_visitor_id', id);
    }
    return id;
}

function getDeviceType() {
    const ua = navigator.userAgent;
    if (/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i.test(ua)) return 'Tablet';
    if (/Mobile|Android|iP(hone|od)|IEMobile|BlackBerry|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(ua)) return 'Mobile';
    return 'Desktop';
}

function getCountry() {
    try {
        const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        const locale = navigator.language || navigator.userLanguage || 'en-US';
        return `${locale.split('-')[1] || 'Unknown'} (${timezone})`;
    } catch (e) {
        return 'Unknown';
    }
}

window.loadInsights = async () => {
    try {
        const visitsSnap = await getDocs(collection(db, "visits"));
        const visits = [];
        visitsSnap.forEach(doc => visits.push(doc.data()));
        
        // Filter by date range
        const dateRange = document.getElementById('dateRange')?.value || '30';
        let filteredVisits = visits;
        if (dateRange !== 'all') {
            const daysAgo = parseInt(dateRange);
            const cutoffDate = new Date();
            cutoffDate.setDate(cutoffDate.getDate() - daysAgo);
            filteredVisits = visits.filter(v => {
                const vDate = v.timestamp?.toDate ? v.timestamp.toDate() : new Date(v.timestamp);
                return vDate >= cutoffDate;
            });
        }
        
        // Total visits
        document.getElementById('totalVisits').textContent = filteredVisits.length;
        
        // Unique visitors
        const unique = new Set(filteredVisits.map(v => v.visitorId)).size;
        document.getElementById('uniqueVisitors').textContent = unique;
        
        // Today visits
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const todayCount = filteredVisits.filter(v => {
            const vDate = v.timestamp?.toDate ? v.timestamp.toDate() : new Date(v.timestamp);
            return vDate >= today;
        }).length;
        document.getElementById('todayVisits').textContent = todayCount;
        
        // Average per day
        const daysCount = dateRange === 'all' ? Math.ceil(visits.length / 30) : parseInt(dateRange);
        const avgVisits = Math.round(filteredVisits.length / daysCount);
        document.getElementById('avgVisits').textContent = avgVisits;
        
        // Country stats
        const countryMap = {};
        filteredVisits.forEach(v => {
            countryMap[v.country] = (countryMap[v.country] || 0) + 1;
        });
        const topCountries = Object.entries(countryMap).sort((a, b) => b[1] - a[1]).slice(0, 10);
        const countryList = document.getElementById('countryList');
        countryList.innerHTML = topCountries.map(([country, count]) => `
            <div class="flex justify-between items-center p-1.5 md:p-2 bg-white rounded hover:bg-gray-50 transition text-xs md:text-sm">
                <span class="text-gray-700 font-medium truncate">${country}</span>
                <span class="text-purple-600 font-bold flex-shrink-0 ml-2">${count}</span>
            </div>
        `).join('') || '<div class="text-gray-400 text-xs md:text-sm p-3 text-center">No data yet</div>';
        
        // Page stats
        const pageMap = {};
        filteredVisits.forEach(v => {
            const page = v.page || '/';
            pageMap[page] = (pageMap[page] || 0) + 1;
        });
        const topPages = Object.entries(pageMap).sort((a, b) => b[1] - a[1]).slice(0, 10);
        const pageList = document.getElementById('pageList');
        pageList.innerHTML = topPages.map(([page, count]) => `
            <div class="flex justify-between items-center p-1.5 md:p-2 bg-white rounded hover:bg-gray-50 transition text-xs md:text-sm">
                <span class="text-gray-700 font-mono truncate">${page}</span>
                <span class="text-orange-600 font-bold flex-shrink-0 ml-2">${count}</span>
            </div>
        `).join('') || '<div class="text-gray-400 text-xs md:text-sm p-3 text-center">No data yet</div>';
        
        // Device stats for chart
        const deviceMap = {};
        filteredVisits.forEach(v => {
            deviceMap[v.deviceType] = (deviceMap[v.deviceType] || 0) + 1;
        });
        
        // Recent activity
        const recent = filteredVisits.sort((a, b) => {
            const aTime = a.timestamp?.toDate ? a.timestamp.toDate() : new Date(a.timestamp);
            const bTime = b.timestamp?.toDate ? b.timestamp.toDate() : new Date(b.timestamp);
            return bTime - aTime;
        }).slice(0, 20);
        const activityList = document.getElementById('recentActivity');
        activityList.innerHTML = recent.map(v => {
            const time = v.timestamp?.toDate ? v.timestamp.toDate() : new Date(v.timestamp);
            const deviceIcon = v.deviceType === 'Mobile' ? 'ph-device-mobile' : (v.deviceType === 'Tablet' ? 'ph-device-tablet' : 'ph-desktop');
            const timeStr = time.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
            return `<div class="flex flex-col md:flex-row md:justify-between md:items-center p-1.5 md:p-2 border-b border-gray-100 hover:bg-white transition gap-1">
                <div class="flex items-center gap-2 min-w-0">
                    <i class="ph-bold ${deviceIcon} text-gray-500 flex-shrink-0"></i>
                    <span class="text-gray-700 font-medium truncate">${v.country}</span>
                    <span class="text-gray-400">•</span>
                    <span class="text-gray-500 truncate">${v.page || '/'}</span>
                </div>
                <span class="text-gray-400 flex-shrink-0">${timeStr}</span>
            </div>`;
        }).join('') || '<div class="text-gray-400 text-xs md:text-sm p-3 text-center">No activity yet</div>';
        
        // Create visits trend chart
        createVisitsTrendChart(filteredVisits, dateRange);
        
        // Create device chart
        createDeviceChart(deviceMap);
        
    } catch (e) {
        console.error('Insights error:', e);
        showToast('Error loading insights: ' + e.message, 'error');
    }
};

// Chart for visits trend
let visitsChartInstance = null;
function createVisitsTrendChart(visits, dateRange) {
    const canvas = document.getElementById('visitsChart');
    if (!canvas) return;
    
    // Group visits by date
    const dateMap = {};
    visits.forEach(v => {
        const vDate = v.timestamp?.toDate ? v.timestamp.toDate() : new Date(v.timestamp);
        const dateKey = vDate.toISOString().split('T')[0];
        dateMap[dateKey] = (dateMap[dateKey] || 0) + 1;
    });
    
    // Generate labels and data for last N days
    const days = dateRange === 'all' ? 30 : parseInt(dateRange);
    const labels = [];
    const data = [];
    let maxVisits = 0;
    for (let i = days - 1; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const key = d.toISOString().split('T')[0];
        const visitCount = dateMap[key] || 0;
        labels.push(d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
        data.push(visitCount);
        maxVisits = Math.max(maxVisits, visitCount);
    }
    
    // Calculate average
    const avgVisits = Math.round(data.reduce((a, b) => a + b, 0) / data.length);
    
    // Destroy old chart
    if (visitsChartInstance) {
        visitsChartInstance.destroy();
    }
    
    // Create new chart with enhanced options
    visitsChartInstance = new Chart(canvas, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Daily Visits',
                data: data,
                borderColor: 'rgb(59, 130, 246)',
                backgroundColor: 'rgba(59, 130, 246, 0.08)',
                borderWidth: 2.5,
                pointRadius: 4,
                pointBackgroundColor: 'rgb(59, 130, 246)',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointHoverRadius: 6,
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false
            },
            plugins: {
                legend: { 
                    display: true,
                    labels: {
                        usePointStyle: true,
                        padding: 15,
                        font: { size: 12, weight: 'bold' }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    padding: 10,
                    titleFont: { size: 13, weight: 'bold' },
                    bodyFont: { size: 12 },
                    callbacks: {
                        afterLabel: () => `Average: ${avgVisits} | Peak: ${maxVisits}`
                    }
                }
            },
            scales: {
                y: { 
                    beginAtZero: true, 
                    max: maxVisits * 1.1,
                    ticks: { precision: 0, font: { size: 11 } },
                    grid: { color: 'rgba(0, 0, 0, 0.05)' }
                },
                x: {
                    ticks: { font: { size: 10 } },
                    grid: { display: false }
                }
            }
        }
    });
}

// Chart for device distribution
let deviceChartInstance = null;
function createDeviceChart(deviceMap) {
    const canvas = document.getElementById('deviceChart');
    if (!canvas) return;
    
    const labels = Object.keys(deviceMap);
    const data = Object.values(deviceMap);
    const total = data.reduce((a, b) => a + b, 0);
    const colors = ['#10b981', '#3b82f6', '#f59e0b'];
    
    // Destroy old chart
    if (deviceChartInstance) {
        deviceChartInstance.destroy();
    }
    
    // Create new chart with enhanced styling
    deviceChartInstance = new Chart(canvas, {
        type: 'doughnut',
        data: {
            labels: labels.map((label, i) => `${label} (${data[i]} - ${Math.round((data[i]/total)*100)}%)`),
            datasets: [{
                data: data,
                backgroundColor: colors.slice(0, labels.length),
                borderColor: '#fff',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        usePointStyle: true,
                        padding: 15,
                        font: { size: 12, weight: 'bold' }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    padding: 10,
                    titleFont: { size: 13, weight: 'bold' },
                    bodyFont: { size: 12 },
                    callbacks: {
                        label: function(context) {
                            const percentage = Math.round((context.parsed / total) * 100);
                            return `${context.label.split('(')[0].trim()}: ${context.parsed} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}

// Filter insights by date range
window.filterInsights = function() {
    loadInsights();
};


// ==========================================
// 5. SITE SETTINGS MANAGEMENT
// ==========================================

window.saveSettings = async () => {
    const settingsData = {
        siteName: document.getElementById('siteName').value,
        siteTagline: document.getElementById('siteTagline').value,
        logoUrl: document.getElementById('logoUrl').value,
        contactEmail: document.getElementById('contactEmail').value,
        dmcaEmail: document.getElementById('dmcaEmail').value,
        businessEmail: document.getElementById('businessEmail').value,
        updatedAt: serverTimestamp()
    };
    
    try {
        const settingsRef = doc(db, "settings", "siteConfig");
        await setDoc(settingsRef, settingsData, { merge: true });
        showToast('Settings saved successfully!', 'success');
        window.siteSettings = settingsData;
    } catch(e) { showToast('Error: ' + e.message, 'error'); }
};

window.loadSettings = async () => {
    try {
        const settingsRef = doc(db, "settings", "siteConfig");
        const docSnap = await getDoc(settingsRef);
        if(docSnap.exists()) {
            const data = docSnap.data();
            document.getElementById('siteName').value = data.siteName || 'Alvee Mods';
            document.getElementById('siteTagline').value = data.siteTagline || '';
            document.getElementById('logoUrl').value = data.logoUrl || 'site_logo.jpg';
            document.getElementById('contactEmail').value = data.contactEmail || 'support@alveemods.net';
            document.getElementById('dmcaEmail').value = data.dmcaEmail || 'dmca@alveemods.net';
            document.getElementById('businessEmail').value = data.businessEmail || 'business@alveemods.net';
            const logo = data.logoUrl || 'site_logo.jpg';
            document.getElementById('logoPreviewImg').src = logo;
            document.getElementById('logoPreview').classList.remove('hidden');
        }
    } catch(e) { console.log('No settings found'); }
};

export async function loadSiteSettings() {
    try {
        const defaults = { siteName: 'Alvee Mods', siteTagline: 'Your trusted Android APK destination', logoUrl: 'site_logo.jpg' };
        const settingsRef = doc(db, "settings", "siteConfig");
        const docSnap = await getDoc(settingsRef);
        if(docSnap.exists()) {
            const merged = { ...defaults, ...docSnap.data() };
            window.siteSettings = merged;
            return merged;
        }
        window.siteSettings = defaults;
        return defaults;
    } catch(e) { return { siteName: 'Alvee Mods', logoUrl: 'site_logo.jpg' }; }
}

// Global scope
window.closeSuccessScreen = () => { document.getElementById('successScreen').classList.add('hidden'); window.resetForm(); }
window.deleteApp = async (id) => { if(confirm("Delete this app?")) { await deleteDoc(doc(db, "apps", id)); loadAdminList(); }};
window.editApp = async (id) => {
    try {
        const docSnap = await getDoc(doc(db, "apps", id));
        if (docSnap.exists()) {
            const data = docSnap.data();
            isEditMode = true; currentEditId = id;
            document.getElementById('appName').value = data.name||''; document.getElementById('packageName').value = data.packageName||''; document.getElementById('developer').value = data.developer||''; document.getElementById('category').value = data.category||''; document.getElementById('version').value = data.version||''; document.getElementById('size').value = data.size||''; document.getElementById('apkUrl').value = data.apkUrl||''; document.getElementById('iconUrl').value = data.iconUrl||''; document.getElementById('screenshots').value = data.screenshots||'';
            const t = data.techData || {};
            document.getElementById('t_verCode').value = t.verCode||''; document.getElementById('t_date').value = t.date||''; document.getElementById('t_compress').value = t.compress||'Enabled'; document.getElementById('t_minSdk').value = t.minSdk||''; document.getElementById('t_targetSdk').value = t.targetSdk||''; document.getElementById('t_compileSdk').value = t.compileSdk||''; document.getElementById('t_abi').value = t.abi||''; document.getElementById('t_devices').value = t.devices||''; document.getElementById('t_v1').checked = t.v1||false; document.getElementById('t_v2').checked = t.v2||false; document.getElementById('t_v3').checked = t.v3||false; document.getElementById('t_v4').checked = t.v4||false; document.getElementById('t_algo').value = t.algo||''; document.getElementById('t_sha1').value = t.sha1||''; document.getElementById('t_sha256').value = t.sha256||''; document.getElementById('t_issuer').value = t.issuer||''; document.getElementById('t_proguard').value = t.proguard||'Enabled'; document.getElementById('t_obfus').value = t.obfus||'Enabled'; document.getElementById('t_debug').value = t.debug||'False'; document.getElementById('t_perms').value = t.perms||'';
            document.getElementById('uploadBtn').innerText = "Update App"; document.getElementById('formTitle').innerHTML = `<i class="ph-bold ph-pencil-simple text-blue-600"></i> Edit App`; window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    } catch(e) { alert(e.message); }
};
window.resetForm = () => { document.getElementById('uploadForm').reset(); isEditMode = false; currentEditId = null; document.getElementById('uploadBtn').innerText = "Save Data"; document.getElementById('formTitle').innerText = "Add New App"; };
window.logout = () => { 
    signOut(auth).then(() => {
        window.location.href = 'admin.html';
    });
};
window.setupAdmin = async () => { try { await createUserWithEmailAndPassword(auth, "admin@admin.com", "admin1"); alert("Admin Created! (admin@admin.com / admin1)"); } catch (e) { alert(e.message); } };

// ==========================================
// PRODUCTION-READY: VALIDATION & ERROR HANDLING
// ==========================================

/**
 * Validation Rules for Admin Forms
 */
const validationRules = {
    appName: { minLength: 2, maxLength: 100, required: true, pattern: /^[a-zA-Z0-9\s\-\.]+$/, message: 'App name: 2-100 chars, alphanumeric only' },
    packageName: { minLength: 3, maxLength: 150, required: true, pattern: /^[a-zA-Z0-9._]+$/, message: 'Package name: valid format required (e.g. com.example.app)' },
    developer: { minLength: 2, maxLength: 100, required: true, pattern: /^[a-zA-Z\s\-\.]+$/, message: 'Developer: 2-100 chars, letters only' },
    version: { minLength: 1, maxLength: 20, required: true, pattern: /^[0-9v.]+$/, message: 'Version: valid format (e.g. 1.0.0)' },
    size: { minLength: 1, maxLength: 50, required: true, pattern: /^[0-9.]+\s*(MB|GB|mb|gb)$/, message: 'Size: format like "50 MB" or "1.5 GB"' },
    category: { required: true, message: 'Category is required' },
    apkUrl: { required: true, pattern: /^https?:\/\/.+\.(apk)$/i, message: 'APK URL must be valid HTTP(S) URL ending in .apk' },
    iconUrl: { pattern: /^https?:\/\/.+/, message: 'Icon URL must be valid HTTP(S) URL' },
    bannerTitle: { minLength: 2, maxLength: 100, required: true, message: 'Banner title: 2-100 chars' },
    bannerLink: { pattern: /^(https?:\/\/.+|[a-z\-]+\.html\?id=.+)$/, message: 'Banner link must be valid URL or app link' },
    sectionName: { minLength: 2, maxLength: 50, required: true, message: 'Section name: 2-50 chars' }
};

/**
 * Validate form input against rules
 */
function validateField(fieldId, rules) {
    const field = document.getElementById(fieldId);
    if (!field) return true;
    
    const value = field.value.trim();
    
    if (rules.required && !value) {
        return { valid: false, error: `${rules.message || fieldId} is required` };
    }
    
    if (value && rules.minLength && value.length < rules.minLength) {
        return { valid: false, error: `${rules.message || fieldId} must be at least ${rules.minLength} characters` };
    }
    
    if (value && rules.maxLength && value.length > rules.maxLength) {
        return { valid: false, error: `${rules.message || fieldId} cannot exceed ${rules.maxLength} characters` };
    }
    
    if (value && rules.pattern && !rules.pattern.test(value)) {
        return { valid: false, error: rules.message || `${fieldId} format is invalid` };
    }
    
    return { valid: true };
}

/**
 * Validate entire form before submission
 */
function validateForm(formType) {
    const errors = [];
    
    if (formType === 'app') {
        const fieldsToValidate = ['appName', 'packageName', 'developer', 'version', 'size', 'category', 'apkUrl'];
        fieldsToValidate.forEach(fieldId => {
            const result = validateField(fieldId, validationRules[fieldId] || {});
            if (!result.valid) errors.push(result.error);
        });
    } else if (formType === 'banner') {
        const fieldsToValidate = ['bannerTitle'];
        fieldsToValidate.forEach(fieldId => {
            const result = validateField(fieldId, validationRules[fieldId] || {});
            if (!result.valid) errors.push(result.error);
        });
    } else if (formType === 'section') {
        const fieldsToValidate = ['sectionName'];
        fieldsToValidate.forEach(fieldId => {
            const result = validateField(fieldId, validationRules[fieldId] || {});
            if (!result.valid) errors.push(result.error);
        });
    }
    
    if (errors.length > 0) {
        showToast(errors[0], 'error');
        return false;
    }
    
    return true;
}

/**
 * Sanitize user input to prevent XSS
 */
function sanitizeInput(input) {
    const textarea = document.createElement('textarea');
    textarea.textContent = input;
    return textarea.innerHTML;
}

/**
 * Show empty state when no data available
 */
function showEmptyState(containerId, message = 'No data available') {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    container.innerHTML = `
        <div class="text-center py-12">
            <i class="ph-bold ph-folder-open text-gray-300 text-5xl mb-4"></i>
            <p class="text-gray-500 text-lg">${sanitizeInput(message)}</p>
        </div>
    `;
}

/**
 * Enhanced saveApp with validation and error handling
 */
window.saveApp = async () => {
    if (!validateForm('app')) return;
    
    const saveBtn = document.getElementById('uploadBtn');
    const originalText = saveBtn.innerText;
    saveBtn.disabled = true;
    saveBtn.innerText = '⏳ Saving...';
    
    try {
        const appData = {
            name: sanitizeInput(document.getElementById('appName').value.trim()),
            packageName: sanitizeInput(document.getElementById('packageName').value.trim()),
            developer: sanitizeInput(document.getElementById('developer').value.trim()),
            category: document.getElementById('category').value,
            version: sanitizeInput(document.getElementById('version').value.trim()),
            size: sanitizeInput(document.getElementById('size').value.trim()),
            apkUrl: document.getElementById('apkUrl').value.trim(),
            iconUrl: document.getElementById('iconUrl').value.trim(),
            screenshots: document.getElementById('screenshots').value.trim(),
            techData: {
                verCode: sanitizeInput(document.getElementById('t_verCode').value.trim()),
                date: document.getElementById('t_date').value,
                compress: document.getElementById('t_compress').value,
                minSdk: sanitizeInput(document.getElementById('t_minSdk').value.trim()),
                targetSdk: sanitizeInput(document.getElementById('t_targetSdk').value.trim()),
                compileSdk: sanitizeInput(document.getElementById('t_compileSdk').value.trim()),
                abi: sanitizeInput(document.getElementById('t_abi').value.trim()),
                devices: sanitizeInput(document.getElementById('t_devices').value.trim()),
                v1: document.getElementById('t_v1').checked,
                v2: document.getElementById('t_v2').checked,
                v3: document.getElementById('t_v3').checked,
                v4: document.getElementById('t_v4').checked,
                algo: document.getElementById('t_algo').value,
                sha1: sanitizeInput(document.getElementById('t_sha1').value.trim()),
                sha256: sanitizeInput(document.getElementById('t_sha256').value.trim()),
                issuer: sanitizeInput(document.getElementById('t_issuer').value.trim()),
                proguard: document.getElementById('t_proguard').value,
                obfus: document.getElementById('t_obfus').value,
                debug: document.getElementById('t_debug').value,
                perms: sanitizeInput(document.getElementById('t_perms').value.trim())
            },
            updatedAt: serverTimestamp()
        };
        
        if (!isEditMode) {
            appData.uploads = 0;
            appData.uploadedAt = serverTimestamp();
        }
        
        if (isEditMode && currentEditId) {
            await updateDoc(doc(db, 'apps', currentEditId), appData);
            showToast('✅ App updated successfully!', 'success');
        } else {
            await addDoc(collection(db, 'apps'), appData);
            showToast('✅ App added successfully!', 'success');
        }
        
        window.resetForm();
        await loadAdminList();
        document.getElementById('successScreen').classList.remove('hidden');
        setTimeout(() => {
            document.getElementById('successScreen').classList.add('hidden');
        }, 3000);
        
    } catch(error) {
        showToast('❌ Error: ' + (error.message || 'Failed to save app'), 'error');
    } finally {
        saveBtn.disabled = false;
        saveBtn.innerText = originalText;
    }
};

/**
 * Enhanced saveBanner with validation
 */
window.saveBanner = async () => {
    if (!validateForm('banner')) return;
    
    const saveBtn = document.querySelector('[onclick="saveBanner()"]') || document.getElementById('saveBannerBtn');
    const originalText = saveBtn?.innerText || 'Save Banner';
    if (saveBtn) { saveBtn.disabled = true; saveBtn.innerText = '⏳ Saving...'; }
    
    try {
        const bannerData = {
            title: sanitizeInput(document.getElementById('bannerTitle').value.trim()),
            description: sanitizeInput(document.getElementById('bannerDesc').value.trim()),
            imageUrl: document.getElementById('bannerImageUrl').value.trim(),
            link: document.getElementById('bannerLink').value.trim(),
            order: parseInt(document.getElementById('bannerOrder').value) || 0,
            updatedAt: serverTimestamp()
        };
        
        if (!isEditMode) {
            bannerData.createdAt = serverTimestamp();
        }
        
        if (isEditMode && currentEditId) {
            await updateDoc(doc(db, 'banners', currentEditId), bannerData);
            showToast('✅ Banner updated!', 'success');
        } else {
            await addDoc(collection(db, 'banners'), bannerData);
            showToast('✅ Banner created!', 'success');
        }
        
        isEditMode = false;
        currentEditId = null;
        document.getElementById('bannerForm').reset();
        await loadBannerList();
        
    } catch(error) {
        showToast('❌ Error: ' + (error.message || 'Failed to save banner'), 'error');
    } finally {
        if (saveBtn) { saveBtn.disabled = false; saveBtn.innerText = originalText; }
    }
};

/**
 * Enhanced saveSection with validation
 */
window.saveSection = async () => {
    if (!validateForm('section')) return;
    
    const saveBtn = document.querySelector('[onclick="saveSection()"]') || document.getElementById('saveSectionBtn');
    const originalText = saveBtn?.innerText || 'Save Section';
    if (saveBtn) { saveBtn.disabled = true; saveBtn.innerText = '⏳ Saving...'; }
    
    try {
        const sectionData = {
            name: sanitizeInput(document.getElementById('sectionName').value.trim()),
            query: document.getElementById('sectionQuery').value,
            limit: parseInt(document.getElementById('sectionLimit').value) || 10,
            visible: document.getElementById('sectionVisible').checked,
            updatedAt: serverTimestamp()
        };
        
        if (!isEditMode) {
            sectionData.createdAt = serverTimestamp();
        }
        
        if (isEditMode && currentEditId) {
            await updateDoc(doc(db, 'sections', currentEditId), sectionData);
            showToast('✅ Section updated!', 'success');
        } else {
            await addDoc(collection(db, 'sections'), sectionData);
            showToast('✅ Section created!', 'success');
        }
        
        isEditMode = false;
        currentEditId = null;
        document.getElementById('sectionForm').reset();
        await loadSectionList();
        
    } catch(error) {
        showToast('❌ Error: ' + (error.message || 'Failed to save section'), 'error');
    } finally {
        if (saveBtn) { saveBtn.disabled = false; saveBtn.innerText = originalText; }
    }
};

// ==========================================
// PRODUCTION: ANALYTICS & ERROR TRACKING
// ==========================================

/**
 * Log event to Firestore for analytics
 * @param {string} eventName - Name of the event
 * @param {object} data - Additional data to log
 */
export async function logEvent(eventName, data = {}) {
    try {
        // Only log if visitor tracking is enabled
        if (!window.visitorId) return;
        
        const eventData = {
            event: eventName,
            visitorId: window.visitorId,
            timestamp: serverTimestamp(),
            url: window.location.pathname,
            userAgent: navigator.userAgent,
            ...data
        };
        
        // Non-blocking: fire and forget
        addDoc(collection(db, 'events'), eventData).catch(err => {
            // Silent fail for analytics
        });
    } catch(e) {
        // Never crash due to analytics
    }
}

/**
 * Log JavaScript errors to Firebase for monitoring
 */
window.addEventListener('error', (event) => {
    try {
        const errorData = {
            type: 'javascript_error',
            message: event.message,
            filename: event.filename,
            lineno: event.lineno,
            colno: event.colno,
            stack: event.error?.stack || '',
            timestamp: serverTimestamp(),
            url: window.location.href,
            visitorId: window.visitorId || 'unknown'
        };
        
        // Log to Firebase (non-blocking)
        addDoc(collection(db, 'errors'), errorData).catch(() => {});
    } catch(e) {}
});

/**
 * Track unhandled promise rejections
 */
window.addEventListener('unhandledrejection', (event) => {
    try {
        const errorData = {
            type: 'unhandled_rejection',
            reason: event.reason?.message || String(event.reason),
            timestamp: serverTimestamp(),
            url: window.location.href,
            visitorId: window.visitorId || 'unknown'
        };
        
        addDoc(collection(db, 'errors'), errorData).catch(() => {});
    } catch(e) {}
});

/**
 * Enhanced app download tracking with analytics
 */
window.trackDownload = async (appId, appName) => {
    try {
        const appRef = doc(db, 'apps', appId);
        await updateDoc(appRef, { uploads: increment(1) });
        
        // Log event for analytics
        await logEvent('app_download', {
            appId: appId,
            appName: appName,
            downloadSource: 'download_button'
        });
        
        showToast('✅ Download started! Check your downloads folder.', 'success');
    } catch(e) {
        showToast('Download initiated!', 'info');
        // Still fire analytics event even if update fails
        await logEvent('app_download', { appId, appName });
    }
};

/**
 * Performance monitoring - log slow pages
 */
if (window.PerformanceObserver) {
    try {
        const observer = new PerformanceObserver((list) => {
            for (const entry of list.getEntries()) {
                if (entry.duration > 3000) { // Log if page takes >3 seconds
                    logEvent('slow_page_load', {
                        duration: Math.round(entry.duration),
                        name: entry.name,
                        type: entry.entryType
                    });
                }
            }
        });
        observer.observe({ type: 'navigation', buffered: true });
    } catch(e) {}
}

/**
 * Export all production utilities for other scripts
 */
export { validateField, validateForm, sanitizeInput, showEmptyState };